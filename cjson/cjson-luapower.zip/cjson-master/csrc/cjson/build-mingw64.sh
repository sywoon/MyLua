P=mingw64 D=cjson.dll A=cjson.a \
	L="-s -static-libgcc -L../../bin/mingw64 -llua51" ./build.sh
