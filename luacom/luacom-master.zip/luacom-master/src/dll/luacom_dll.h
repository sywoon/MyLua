
#include "lua.h"

extern "C" int luacom_openlib(lua_State* L);

extern "C" int luaopen_luacom(lua_State* L);



