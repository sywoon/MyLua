P=linux64 C=-fPIC L="-s -static-libgcc" D=cjson.so A=libcjson.a ./build.sh
