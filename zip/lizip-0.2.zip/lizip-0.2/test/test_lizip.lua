-- test_lizip.lua

local zt, ut = {}, {} -- ziptest, unziptest

local function assert_type (val, expected)
  local real = type(val)
  if real == expected then return val end
  error (expected .. " expected, got " .. real, 3)
end

local function assert_table(f)    return assert_type(f, "table")    end
local function assert_function(f) return assert_type(f, "function") end
local function assert_boolean(f)  return assert_type(f, "boolean")  end
local function assert_string(f)   return assert_type(f, "string")   end
local function assert_number(f)   return assert_type(f, "number")   end

local function quoted (s)
  return '"' .. s .. '"'
end

local function joinpath (...)
  return table.concat({...}, "\\")
end

local function fileexist (fname)
  local fp = io.open(fname)
  if fp then fp:close(); return true; end
  return false
end

local function direxist (dname)
  local fname = joinpath(dname, "tmp1.tmp")
  if fileexist(fname) then return true end
  local fp = io.open(fname, "w")
  if fp then fp:close(); os.remove(fname); return true; end
  return false
end

local function createfile (fname, str)
  local fp = assert(io.open(fname, "wb"))
  fp:write(str)
  fp:close()
end

local function remove_files (...)
  for k = 1, select("#", ...) do
    local files = select(k, ...)
    local tp = type(files)
    if tp == "string" then
      os.remove(files)
      assert(not fileexist(files))
    elseif tp == "table" then
      for i,v in ipairs(files) do
        os.remove(v)
        assert(not fileexist(v))
      end
    end
  end
end

local function readfile (fname, mode)
  local fp, msg = io.open(fname, mode or "r")
  if not fp then return fp, msg end
  local s, msg = fp:read("*all")
  fp:close()
  if not s then return s, msg end
  return s
end

function writefile (s, fname, mode)
  local fp, msg = io.open(fname, mode or "w")
  if not fp then return fp, msg end
  fp:write(s)
  fp:close()
  return true
end

local function prepare_dir (dir)
  -- assure the directory exists
  local existed = direxist(dir)
  if not existed then
    os.execute("mkdir " .. quoted(dir))
    assert(direxist(dir), "could not create a directory")
  end
  return existed
end

local function prepare_files (dir, nocreate)
  -- create files to zip
  local files = {
    joinpath(dir, "MixedCaseName"),
    joinpath(dir, "name.with.dots"),
    joinpath(dir, "name with spaces"),
  }
  if not nocreate then
    for i,v in ipairs(files) do createfile(v,v) end
  else
    remove_files(files)
  end

  -- assure the target file doesn't exist
  local zipfile = joinpath(dir, "zip1.tmp.zip")
  remove_files(zipfile)

  return files, zipfile
end

local function cleanup_dir (dir, existed)
  if not existed then
    os.execute("rmdir " .. quoted(dir))
    assert(not direxist(dir), "could not remove a directory")
  end
end

-------------------------------------------------------------------------------
-- ZIP TESTS
-------------------------------------------------------------------------------

zt.return_codes = {
  ZE_MISS   = -1,
  ZE_OK     = 0,
  ZE_EOF    = 2,
  ZE_FORM   = 3,
  ZE_MEM    = 4,
  ZE_LOGIC  = 5,
  ZE_BIG    = 6,
  ZE_NOTE   = 7,
  ZE_TEST   = 8,
  ZE_ABORT  = 9,
  ZE_TEMP   = 10,
  ZE_READ   = 11,
  ZE_NONE   = 12,
  ZE_NAME   = 13,
  ZE_WRITE  = 14,
  ZE_CREAT  = 15,
  ZE_PARMS  = 16,
  ZE_OPEN   = 18,
  ZE_COMPERR= 19,
  ZE_ZIP64  = 20,
  ZE_MAXERR = 20,
}

function zt.assert_result (refcode, func, ...)
  local function helper (ret1, ...)
    if ret1 ~= zt.return_codes[refcode] then
      error(refcode .. " expected, got " .. tostring(ret1))
    end
    return ...
  end
  return helper(func(...))
end

function zt.test_contents()
  assert_table(zip)

  assert_function(zip.init)
  assert_function(zip.version)
  assert_function(zip.add)
  assert_function(zip.update)
  assert_function(zip.freshen)
  assert_function(zip.delete)
end

function zt.test_timestamp_change (func, zipfile, file)
  zt.assert_result("ZE_NONE", func, zipfile, file)
  local tm = assert(zip.filetime(file))
  assert(zip.filetime(file, tm + 2))
  zt.assert_result("ZE_OK", func, zipfile, file)
  zt.assert_result("ZE_NONE", func, zipfile, file)
end

function zt.test_add (dir, options)
  local files, zipfile = prepare_files(dir)

  -- test add on non-existent zipfile
  assert(not fileexist(zipfile))
  zt.assert_result("ZE_OK", zip.add, zipfile, files, options)
  assert(fileexist(zipfile))

  -- test add on an existent zipfile
  zt.assert_result("ZE_OK", zip.add, zipfile, files, options)

  remove_files(files, zipfile)
end

function zt.test_update (dir)
  local files, zipfile = prepare_files(dir)

  -- test update on non-existent zipfile
  assert(not fileexist(zipfile))
  zt.assert_result("ZE_OK", zip.update, zipfile, files)
  assert(fileexist(zipfile))

  -- test update with non-modified source files
  zt.assert_result("ZE_NONE", zip.update, zipfile, files)

  -- test delete one file from the zip, then update
  zt.assert_result("ZE_OK", zip.delete, zipfile, files[1], {fQuiet=true})
  zt.assert_result("ZE_OK", zip.update, zipfile, files)
  zt.assert_result("ZE_NONE", zip.update, zipfile, files)

  zt.test_timestamp_change(zip.update, zipfile, files[1])

  remove_files(files, zipfile)
end

function zt.test_freshen (dir)
  local files, zipfile = prepare_files(dir)

  -- test freshen on non-existent zipfile
  assert(not fileexist(zipfile))
  zt.assert_result("ZE_NONE", zip.freshen, zipfile, files)

  -- test add on non-existent zipfile
  zt.assert_result("ZE_OK", zip.add, zipfile, files)
  assert(fileexist(zipfile))

  -- test freshen with non-modified source files
  zt.assert_result("ZE_NONE", zip.freshen, zipfile, files)

  zt.test_timestamp_change(zip.freshen, zipfile, files[1])

  remove_files(files, zipfile)
end

function zt.test_delete (dir)
  local files, zipfile = prepare_files(dir)

  -- test delete on non-existent zipfile
 assert(not fileexist(zipfile))
--~  zt.assert_result("ZE_NONE", zip.delete, zipfile, files)
  zt.assert_result("ZE_OK", zip.delete, zipfile, files)

  -- test add on non-existent zipfile
  zt.assert_result("ZE_OK", zip.add, zipfile, files)
  assert(fileexist(zipfile))

  -- test delete one file from the zip
  zt.assert_result("ZE_OK", zip.delete, zipfile, files[1], {fQuiet=true})

  remove_files(files, zipfile)
end

function zt.test_default_options (opt)
  assert(opt.Date == nil)
  assert(opt.szRootDir == nil)
  assert(opt.szTempDir == nil)
  assert(opt.fSuffix == false)
  assert(opt.fOffsets == false)
  assert(opt.fComment == false)
  assert(opt.fRepair == 0)
  assert(opt.fTemp == false)
  assert(opt.fSystem == false)
  assert(opt.fJunkSFX == false)
  assert(opt.fEncryption == true)
  assert(opt.fQuiet == false)
  assert(opt.fIncludeDate == false)
  assert(opt.fExcludeDate == false)
  assert(opt.fLatestTime == false)
  assert(opt.fVerbose == false)
  assert(opt.fVolume == false)
  assert(opt.fForce == false)
  assert(opt.fPrivilege == false)
  assert(opt.fJunkDir == false)
  assert(opt.fCRLF_LF == false)
  assert(opt.fNoDirEntries == false)
  assert(opt.fExtra == false)
  assert(opt.fLF_CRLF == false)
  assert(opt.fGrow == false)
  assert(opt.fMove == false)
  assert(opt.fRecurse == 0)
  assert(opt.fEncrypt == false)
end

function zt.test_version()
  local v = assert_table(zip.version())
  assert_boolean (v.is_beta)
  assert_boolean (v.uses_zlib)
  assert_boolean (v.fEncryption)
  if v.is_beta then
    assert_string  (v.betalevel)
  end
  assert_string  (v.date)
  if v.uses_zlib then
    assert_string  (v.zlib_version)
  end
  assert_string  (v.zip)
  assert_string  (v.os2dll)
  assert_string  (v.windll)
end

function zt.test_callback_print (dir)
  local n = 0
  local function cprint (msg)
    assert(type(msg) == "string")
    n = n + 1
  end
  zip.init { print = cprint }
  zt.test_add(dir)
  zip.init()
  assert (n > 0)
end

function zt.test_callback_comment (dir)
  local n = 0
  local function comment()
    n = n + 1
    return "my cool comment"
  end
  zip.init { comment = comment }
  local options = {fComment = true}
  zt.test_add(dir, options)
  zip.init()
  assert (n > 0)
end

function zt.test_callback_password (dir)
  local n = 0
  local function pwd (bufsize, mode, name)
    assert(type(bufsize) == "number")
    assert(type(mode) == "string")
    n = n + 1
    return "my password"
  end
  zip.init { password = pwd }
  local options = {fEncrypt = true}
  zt.test_add(dir, options)
  zip.init()
  assert (n > 0)
end

function zt.test_callback_ServiceApplication (dir)
  local n = 0
  local function serviceApp (name, size)
    assert(type(name) == "string")
    assert(type(size) == "number")
    n = n + 1
  end
  zip.init { ServiceApplication = serviceApp }
  zt.test_add(dir)
  zip.init()
  assert (n > 0)
end

function zt.test_init (dir)
  zt.test_callback_print(dir)
  zt.test_callback_comment(dir)
  zt.test_callback_ServiceApplication(dir)
  if zip.version().fEncryption then
    zt.test_callback_password(dir)
  end
end

function zt.test_all (dir)
  zt.test_contents()
  local existed = prepare_dir(dir)

  zt.test_version()

  zt.test_add(dir)
  zt.test_delete(dir)
  zt.test_update(dir)
  zt.test_freshen(dir)

  zt.test_init(dir)

  cleanup_dir(dir, existed)
end

-------------------------------------------------------------------------------
-- UNZIP TESTS
-------------------------------------------------------------------------------

ut.return_codes = {
  PK_OK     =  0,  -- no error
  PK_COOL   =  0,  -- no error
  PK_WARN   =  1,  -- warning error
  PK_ERR    =  2,  -- error in zipfile
  PK_BADERR =  3,  -- severe error in zipfile
  PK_MEM    =  4,  -- insufficient memory (during initialization)
  PK_MEM2   =  5,  -- insufficient memory (password failure)
  PK_MEM3   =  6,  -- insufficient memory (file decompression)
  PK_MEM4   =  7,  -- insufficient memory (memory decompression)
  PK_MEM5   =  8,  -- insufficient memory (not yet used)
  PK_NOZIP  =  9,  -- zipfile not found
  PK_PARAM  = 10,  -- bad or illegal parameters specified
  PK_FIND   = 11,  -- no files found
  PK_DISK   = 50,  -- disk full
  PK_EOF    = 51,  -- unexpected EOF

  IZ_CTRLC  = 80,  -- user hit ^C to terminate
  IZ_UNSUP  = 81,  -- no files found: all unsup. compr/encrypt.
  IZ_BADPWD = 82,  -- no files found: all had bad password
}

function ut.assert_result (refcode, func, ...)
  local function helper (ret1, ...)
    if ret1 ~= ut.return_codes[refcode] then
      error(refcode .. " expected, got " .. tostring(ret1))
    end
    return ...
  end
  return helper(func(...))
end

function ut.test_contents()
  assert_table(unzip)

  assert_function(unzip.init)
  assert_function(unzip.list)
  assert_function(unzip.noprinting)
  assert_function(unzip.test)
  assert_function(unzip.unzip)
  assert_function(unzip.unziptomemory)
  assert_function(unzip.validate)
  assert_function(unzip.version)
end

function ut.test_version()
  local v = assert_table(unzip.version())
  assert_boolean (v.is_beta)
  assert_boolean (v.uses_zlib)
  if v.is_beta then
    assert_string  (v.betalevel)
  end
  assert_string  (v.date)
  if v.uses_zlib then
    assert_string  (v.zlib_version)
  end
  assert_string  (v.unzip)
  assert_string  (v.os2dll)
  assert_string  (v.windll)
end

local zip1_contents =
  "\80\75\3\4\10\0\0\0\0\0\224\178\206\58\39\205\231\53\27\0\0\0\27\0\0"..
  "\0\27\0\17\0\108\122\105\112\95\116\101\109\112\46\116\109\112\47\77"..
  "\105\120\101\100\67\97\115\101\78\97\109\101\85\84\13\0\7\20\78\53"..
  "\74\80\19\52\74\19\78\53\74\108\122\105\112\95\116\101\109\112\46"..
  "\116\109\112\92\77\105\120\101\100\67\97\115\101\78\97\109\101\80\75"..
  "\3\4\10\0\0\0\0\0\224\178\206\58\124\201\164\111\28\0\0\0\28\0\0\0"..
  "\28\0\17\0\108\122\105\112\95\116\101\109\112\46\116\109\112\47\110"..
  "\97\109\101\46\119\105\116\104\46\100\111\116\115\85\84\13\0\7\20\78"..
  "\53\74\80\19\52\74\19\78\53\74\108\122\105\112\95\116\101\109\112\46"..
  "\116\109\112\92\110\97\109\101\46\119\105\116\104\46\100\111\116\115"..
  "\80\75\3\4\10\0\0\0\0\0\224\178\206\58\63\16\225\207\30\0\0\0\30\0\0"..
  "\0\30\0\17\0\108\122\105\112\95\116\101\109\112\46\116\109\112\47"..
  "\110\97\109\101\32\119\105\116\104\32\115\112\97\99\101\115\85\84\13"..
  "\0\7\20\78\53\74\80\19\52\74\19\78\53\74\108\122\105\112\95\116\101"..
  "\109\112\46\116\109\112\92\110\97\109\101\32\119\105\116\104\32\115"..
  "\112\97\99\101\115\80\75\1\2\23\11\10\0\0\0\0\0\224\178\206\58\39"..
  "\205\231\53\27\0\0\0\27\0\0\0\27\0\9\0\0\0\0\0\1\0\32\0\182\129\0\0"..
  "\0\0\108\122\105\112\95\116\101\109\112\46\116\109\112\47\77\105\120"..
  "\101\100\67\97\115\101\78\97\109\101\85\84\5\0\7\20\78\53\74\80\75\1"..
  "\2\23\11\10\0\0\0\0\0\224\178\206\58\124\201\164\111\28\0\0\0\28\0\0"..
  "\0\28\0\9\0\0\0\0\0\1\0\32\0\182\129\101\0\0\0\108\122\105\112\95"..
  "\116\101\109\112\46\116\109\112\47\110\97\109\101\46\119\105\116\104"..
  "\46\100\111\116\115\85\84\5\0\7\20\78\53\74\80\75\1\2\23\11\10\0\0\0"..
  "\0\0\224\178\206\58\63\16\225\207\30\0\0\0\30\0\0\0\30\0\9\0\0\0\0\0"..
  "\1\0\32\0\182\129\204\0\0\0\108\122\105\112\95\116\101\109\112\46"..
  "\116\109\112\47\110\97\109\101\32\119\105\116\104\32\115\112\97\99"..
  "\101\115\85\84\5\0\7\20\78\53\74\80\75\5\6\0\0\0\0\3\0\3\0\250\0\0\0"..
  "\55\1\0\0\0\0"

local zip2_contents_encr =   -- (password = "my password")
  "\80\75\3\4\10\0\9\0\0\0\181\70\207\58\186\189\186\79\21\0\0\0\9\0\0"..
  "\0\22\0\17\0\108\122\105\112\95\116\101\109\112\46\116\109\112\47"..
  "\102\105\108\101\110\97\109\101\85\84\13\0\7\230\225\53\74\208\100"..
  "\53\74\229\225\53\74\47\51\1\156\201\12\195\80\34\39\205\28\58\152"..
  "\98\64\11\74\71\201\234\80\75\7\8\186\189\186\79\21\0\0\0\9\0\0\0\80"..
  "\75\1\2\23\11\10\0\9\0\0\0\181\70\207\58\186\189\186\79\21\0\0\0\9\0"..
  "\0\0\22\0\9\0\0\0\0\0\1\0\32\0\182\129\0\0\0\0\108\122\105\112\95"..
  "\116\101\109\112\46\116\109\112\47\102\105\108\101\110\97\109\101\85"..
  "\84\5\0\7\230\225\53\74\80\75\5\6\0\0\0\0\1\0\1\0\77\0\0\0\106\0\0\0"..
  "\0\0"

function ut.test_unzip (dir)
  ut.assert_result("PK_NOZIP", unzip.unzip, os.tmpname())

  -- get names and create zip file
  local files, zipfile = prepare_files(dir, true)
  assert(writefile(zip1_contents, zipfile, "wb"))

  -- collect helper data
  local times = {}
  ut.assert_result("PK_OK",  unzip.unzip, zipfile, dir)
  for i, f in ipairs(files) do
    assert(fileexist(f))
    times[i] = assert(unzip.filetime(f))
  end
  ----------------------------------------------------------------------------
  ut.assert_result("PK_OK", unzip.unzip, zipfile, dir, files)
  for _, f in ipairs(files) do assert(fileexist(f)) end
  ----------------------------------------------------------------------------

  local function gen (answer)
    local n, f = 0, 8
    return function (filename)
      if filename then n = n + f; f = f * 2; return answer
      else return n
      end
    end
  end

  local function getstate (func)
    local r1 = unzip.filetime(files[1]) == times[1]-2 and 0 or 1
    local r2 = unzip.filetime(files[2]) >  times[2]   and 0 or 2
    local r3 = not fileexist(files[3])                and 0 or 4
    return r1+r2+r3+func()
  end

  local refstates = {
    --                 ""             "n"             "o"
    --[[""]]     28,31,12,15,     4, 4, 4, 4,     7, 7, 7, 7,
    --[["f"]]     8, 9, 8, 9,     0, 0, 0, 0,     1, 1, 1, 1,
    --[["u"]]    12,13,12,13,     4, 4, 4, 4,     5, 5, 5, 5
  }

  local j = 1
  for _,o1 in ipairs {"", "f", "u"} do
    for _,o2 in ipairs {"", "n", "o"} do
      for _,ans in ipairs {"no","yes","none","all",--[["rename"]]} do
        local frepl = gen(ans)
        unzip.init { replace = frepl }
        assert(writefile("foo", files[1]))              -- 1st file: out-of-date
        assert(unzip.filetime(files[1], times[1] - 2))
        assert(writefile("bar", files[2]))              -- 2nd file: up-to-date
        remove_files(files[3])                          -- 3rd file: missing
        ut.assert_result("PK_OK", unzip.unzip, zipfile, dir, o1..o2, files)
        local state = getstate(frepl)
        if state ~= refstates[j] then
          error(string.format("opt=%s, ans=%s, ref=%d, state=%d",
                              o1..o2, ans, refstates[j], state))
        end
        j = j + 1
      end
    end
  end
  unzip.init()
  remove_files(files, zipfile)
end

function ut.test_unziptomemory (dir)
  local files, zipfile = prepare_files(dir)
  assert(writefile(zip1_contents, zipfile, "wb"))

  for _, v in ipairs(files) do
    local s1 = assert(readfile(v))
    local s2 = assert(unzip.unziptomemory(zipfile, v))
    assert(s1 == s2)
  end

  remove_files(files, zipfile)
end

function ut.test_callback_print (dir)
  local n = 0
  local function cprint (msg)
    assert(type(msg) == "string")
    n = n + 1
  end
  unzip.init { print = cprint }
  ut.test_unzip(dir)
  unzip.init()
  assert (n > 0)
end

function ut.test_callback_sound (dir)
  local n = 0
  local files, zipfile = prepare_files(dir)
  assert(writefile(zip1_contents, zipfile, "wb"))
  unzip.init( { sound = function() n=n+1 end; } )
  assert(unzip.unziptomemory(zipfile, files[1]))
  unzip.init()
  remove_files(files, zipfile)
  assert(n > 0)
end

function ut.test_callback_password (dir)
  local n = 0
  local function pwd (bufsize, prompt, filename)
    assert(type(bufsize) == "number")
    assert(type(prompt) == "string")
    assert(type(filename) == "string")
    n = n + 1
    return "my password"
  end

  local zipname, filename = joinpath(dir, "zipname.zip"), joinpath(dir, "filename")
  assert(writefile(zip2_contents_encr, zipname, "wb"))
  assert(not fileexist(filename))

  unzip.init { password = function() return "???" end }
  ut.assert_result("IZ_BADPWD", unzip.unzip, zipname, dir)
  assert(not fileexist(filename))

  n = 0
  unzip.init { password = pwd }
  ut.assert_result("PK_OK", unzip.unzip, zipname, dir)
  assert(fileexist(filename))
  assert (n > 0)

  remove_files(filename, zipname)
  unzip.init()
end

function ut.test_callback_replace (dir)
  local number = 0
  local files, zipfile = prepare_files(dir, true)
  local f1 = files[1]:gsub("\\", "/")
  local f2 = files[2]:gsub("\\", "/")
  local f3 = files[3]:gsub("\\", "/")

  local function replace (filename)
    assert(type(filename) == "string")
    if filename == f1 then number = number + 1
    elseif filename == f2 then number = number + 10
    elseif filename == f3 then number = number + 100
    end
    return "no" --(filename == f2) and "yes" or "no"
  end

  unzip.init { replace = replace }
  assert(writefile(zip1_contents, zipfile, "wb"))

  for k=1,2 do
    ut.assert_result("PK_OK", unzip.unzip, zipfile, dir)
    ut.assert_result("PK_OK", unzip.unzip, zipfile, dir, {PromptToOverwrite=false})
  end
  assert(number == 0)
  for k=1,2 do
    ut.assert_result("PK_OK", unzip.unzip, zipfile, dir, {PromptToOverwrite=true})
  end
  assert(number == 222)

  remove_files(files, zipfile)
  unzip.init()
end

function ut.test_callback_SendApplicationMessage (dir)
  local cnt = 0
  local function msg (ucsize, csiz, cfactor, mo, dy, yr, hh, mm, c, filename,
                      methbuf, crc, fCrypt)
    local szCompFactor
    if cfactor == 100 then
      szCompFactor = "100%%"
    else
      local CompFactorStr = "%s%d%%"
      local sgn = (csiz > ucsize) and '-' or ' '
      szCompFactor = CompFactorStr:format(sgn, cfactor)
    end

    local LongHdrStats = "%7u  %7u %4s  %02u-%02u-%02u  %02u:%02u  %s%s"
    local psLBEntry = LongHdrStats:format(
      ucsize, csiz, szCompFactor, mo, dy, yr, hh, mm, c, filename)
    --print(psLBEntry)
    cnt = cnt + 1
  end

  local zipfile = joinpath(dir, "myzip.zip")
  assert(writefile(zip1_contents, zipfile, "wb"))
  unzip.init( { SendApplicationMessage = msg } )

  ut.assert_result("PK_OK", unzip.list, zipfile)
  assert(cnt == 3)

  unzip.init()
  remove_files(zipfile)
end

function ut.test_callback_ServCallBk (dir)
  local n = 0
  local function serv (fname, fsize)
    assert(type(fname) == "string")
    assert(type(fsize) == "number")
    n = n + 1
  end

  local files, zipfile = prepare_files(dir)
  assert(writefile(zip1_contents, zipfile, "wb"))
  unzip.init( { ServCallBk = serv } )
  assert(unzip.unziptomemory(zipfile, files[1]))
  unzip.init()
  remove_files(files, zipfile)
  assert(n == 1)
end

function ut.test_init (dir)
  ut.test_callback_print(dir)
  ut.test_callback_sound(dir)
  ut.test_callback_replace(dir)
  ut.test_callback_password(dir)
  ut.test_callback_SendApplicationMessage(dir)
  ut.test_callback_ServCallBk(dir)
end

function ut.test_noprinting (dir)
  unzip.noprinting(false)
  ut.test_callback_print(dir)

  unzip.noprinting(true)
  assert(not pcall(ut.test_callback_print, dir))

  unzip.noprinting(false)
  ut.test_callback_print(dir)
end

function ut.test_validate (dir)
  local zipname = joinpath(dir, "myzip.zip")

  assert(writefile(zip1_contents, zipname, "wb"))
  ut.assert_result("PK_OK", unzip.validate, zipname)

  assert(writefile("abcdef", zipname, "wb"))
  ut.assert_result("PK_NOZIP", unzip.validate, zipname)

  remove_files(zipname)
end

function ut.test_test (dir)
  local zipname = joinpath(dir, "myzip.zip")

  assert(writefile(zip1_contents, zipname, "wb"))
  ut.assert_result("PK_OK", unzip.test, zipname)

  assert(writefile("abcdef", zipname, "wb"))
  ut.assert_result("PK_NOZIP", unzip.test, zipname)

  remove_files(zipname)
end

function ut.test_list (dir)
  local zipname = joinpath(dir, "myzip.zip")

  assert(writefile(zip1_contents, zipname, "wb"))
  local result, summary = unzip.list(zipname)
  local summary = ut.assert_result("PK_OK", unzip.list, zipname)
  assert_table(summary)
  assert(summary.NumMembers == 3)

  assert(writefile("abcdef", zipname, "wb"))
  ut.assert_result("PK_NOZIP", unzip.list, zipname)

  remove_files(zipname)
end

function ut.test_all (dir)
  local existed = prepare_dir(dir)

  ut.test_contents()
  ut.test_version()
  ut.test_unzip(dir)
  ut.test_unziptomemory(dir)
  ut.test_init(dir)
  ut.test_noprinting(dir)
  ut.test_validate(dir)
  ut.test_list(dir)
  ut.test_test(dir)

  cleanup_dir(dir, existed)
end

-------------------------------------------------------------------------------
-- MAIN
-------------------------------------------------------------------------------

do
  require "lizip"
  local dir = "lzip_temp.tmp"
  zt.test_all(dir)
  ut.test_all(dir)
  print "All tests OK."
end

