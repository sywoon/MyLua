---
title:   lua-cjson
tagline: JSON encoding & decoding
---

## `local json = require'cjson'`

## Documentation

It's [here](http://www.kyne.com.au/~mark/software/lua-cjson-manual.html#_api_functions).

__NOTE__: Added option `encode_empty_table_as_array`, enabled by default,
to encode empty tables as `[]` instead of `{}`.

